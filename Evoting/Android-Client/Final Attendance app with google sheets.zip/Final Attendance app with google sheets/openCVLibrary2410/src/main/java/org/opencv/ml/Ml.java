
//
// This file is auto-generated. Please don't modify it!
//
package org.opencv.ml;



public class Ml {



}
